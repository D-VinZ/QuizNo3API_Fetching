document.getElementById('fetchButton').addEventListener('click', () => {
    const countrySelect = document.getElementById('countrySelect');
    const selectedCountry = countrySelect.value;

    const url = `https://beers-list.p.rapidapi.com/beers/${selectedCountry}`;
    const options = {
        method: 'GET',
        headers: {
            'X-RapidAPI-Key': 'c12cc64e9fmsh5821ca462fef980p1eff78jsnc101ee4a41a2',
            'X-RapidAPI-Host': 'beers-list.p.rapidapi.com'
        }
    };

    fetch(url, options)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            return response.json();
        })
        .then(beers => {
            displayBeers(beers);
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
});

function displayBeers(beers) {
    const table = document.getElementById('beerTable');
    table.innerHTML = ''; // Clear previous table content

    // Create table header row
    const headerRow = document.createElement('tr');
    ['Title', 'Alcohol', 'Description'].forEach(label => {
        const th = document.createElement('th');
        th.textContent = label;
        headerRow.appendChild(th);
    });
    table.appendChild(headerRow);

    // Populate table with beer data
    beers.forEach(beer => {
        const row = document.createElement('tr');
        ['title', 'alchool', 'description'].forEach(label => {
            const cell = document.createElement('td');
            cell.textContent = beer[label];
            row.appendChild(cell);
        });
        table.appendChild(row);
    });
}
